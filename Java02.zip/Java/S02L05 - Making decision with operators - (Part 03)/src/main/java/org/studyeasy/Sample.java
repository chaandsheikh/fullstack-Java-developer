package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
        boolean x = true;
        boolean y = false;

        if ( y || x ) {
            System.out.println("Condition is TRUE");
        }else {
            System.out.println("Condition is FALSE");
        }

    }
}
