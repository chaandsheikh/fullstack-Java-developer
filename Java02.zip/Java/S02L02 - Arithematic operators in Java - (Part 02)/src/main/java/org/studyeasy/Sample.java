package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
        int mod = 13%2;
        int x = 5;
        System.out.println(x--);
        System.out.println(x);

    }
}
