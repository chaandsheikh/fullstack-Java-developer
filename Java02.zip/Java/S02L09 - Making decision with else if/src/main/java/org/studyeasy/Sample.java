package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

        int x = 4;
        int y = 10;

        if (x == 5){
            System.out.println("X is 5");
        }else if(x > 5){
            System.out.println("X is greater 5");
        }else{
            System.out.println("X is smaller 5");
            if (y == 10){
                System.out.println("y is 10");
            }
        }



    }
}
