package org.studyeasy;

public class Sample {
    public static void main(String[] args) {

        int x = 0;

        while (x < 10){
            System.out.println("Iteration:"+ x);
            x++;
        }


    }
}