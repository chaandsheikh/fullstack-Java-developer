package org.studyeasy;

public class HelloWorld {
    public static void main(String[] args) {

        int value1 = 10, value2;
        value2 = 100*20;


        System.out.println(value2);
    }
}
