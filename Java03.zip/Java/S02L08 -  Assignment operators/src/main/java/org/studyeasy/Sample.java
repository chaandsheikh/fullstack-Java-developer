package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
        int x = 17;
        //x += 5; // x = x + 5
        //x -= 5; // x = x - 5
        //x *= 5; // x = x * 5
        //x /= 4; // x = x / 4
        x %= 5;   // x = x % 5
        System.out.println(x);


    }
}
