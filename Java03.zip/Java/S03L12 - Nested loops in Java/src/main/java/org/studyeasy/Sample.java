package org.studyeasy;

public class Sample {
    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.println("Value of i: "+i+" and value of j: "+j);
            }
            System.out.println("****************");
        }

    }

}

/*

@
@@
@@@
@@@@
@@@@@

 */