package org.studyeasy;

public class Sample {
    public static void main(String[] args) {

     int []x = {1,2,3,4};

        for (int temp: x) {
            System.out.println(temp);
        }



    }

}