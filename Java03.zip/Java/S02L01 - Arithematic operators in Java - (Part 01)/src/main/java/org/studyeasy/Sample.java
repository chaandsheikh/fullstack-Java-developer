package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
        int x = 12/2;
        String text = "Study" + "Easy";
        System.out.println(x);

    }
}
