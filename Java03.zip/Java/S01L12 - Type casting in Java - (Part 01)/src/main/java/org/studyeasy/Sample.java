package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

        short a1 = 200;
        byte a2 = (byte)a1;
        System.out.println(a2);


    }
}
