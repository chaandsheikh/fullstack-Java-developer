package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

        int x = 11;
       // System.out.println(x + 10);

        String result = (x == 10)?"X is 10":"X is not 10";
        System.out.println(result);


    }
}
