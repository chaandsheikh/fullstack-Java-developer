package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
        int x = 6;

        if ( x != 6) {
            System.out.println("X is not 6");
        }else {
            System.out.println("X is 6");
        }

        System.out.println("Sample code");

    }
}
