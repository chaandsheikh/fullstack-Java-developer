package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {
        int x = 5;

        if ( x >= 5) {
            System.out.println("X is greater or equal to 5");
        }else {
            System.out.println("X is lower than 5");
        }

    }
}
