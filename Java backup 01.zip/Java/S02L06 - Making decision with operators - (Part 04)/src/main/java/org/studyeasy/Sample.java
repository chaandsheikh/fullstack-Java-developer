package org.studyeasy;
/* Author: Chand Sheikh */

public class Sample {
    public static void main(String[] args) {

//        int x  = 5;
//        int y = 10;
//
//        if ( (x < y) && (y >= 10) ) {
//            System.out.println("Condition is TRUE");
//        }else {
//            System.out.println("Condition is FALSE");
//        }

        int ageOfBoy = 20;
        int ageOfGirl = 28;

        if ((ageOfBoy >= 21) && (ageOfGirl >= 18)) {
            System.out.println("Eligible for marriage");
        } else {
            System.out.println("Wait for it kiddo!");
        }


    }
}
